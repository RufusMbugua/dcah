<div class="banner">
	<div class="logo">
		<img src="<?php echo base_url(); ?>images/coat_of_arms-resized.png" />

	</div>
	<div class="credentials">
		<div class="title">
			Ministry Of Public Health and Sanitation
		</div>
		<div class="subtitle">
			Department of Family Health<p></p>
		</div>
		<div class="division">
			Division of Reproductive Health (DRH)<p></p>
		</div>
		<div class="division">
			Division of Child and Adolescent Health (DCAH)<p></p><p></p>
		</div>
	</div>
	<div class="date">

		<?php echo date("l F d, Y"); ?>
	</div>
</div>