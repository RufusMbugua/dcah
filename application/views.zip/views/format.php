<section class="block">
	<section class="column" style="margin-bottom:30px">
		<section class="row-title">
			MCH Contanct
		</section>
		<section class="row2">
			<section class="left">
				<label>Name:</label>
			</section>
			<section class="right">
				<input type="text" name="MCHContactPerson" id="MCHContactPerson"/>
			</section>
		</section>
		<section class="row2">
			<section class="left">
				<label>Telephone:</label>
			</section>
			<section class="right">

			</section>

		</section>

		<section class="row2">
			<section class="left">
				<label>Cell 1:</label>
			</section>
			<section class="right">
				<input type="text" name="MCHTelephone" id="MCHTelephone" maxlength="14"/>
			</section>

		</section>

		<section class="row2">
			<section class="left">
				<label>Cell 2:</label>
			</section>
			<section class="right">
				<input type="text" name="MCHAltTelephone" id="MCHAltTelephone" maxlength="14"/>
			</section>

		</section>

		<section class="row2">
			<section class="left">
				<label>Email:</label>
			</section>
			<section class="right">
				<input type="email" name="MCHEmail" id="MCHEmail" maxlength="90"/>
				<input type="hidden"  name="MCHMFC" id="MCHMFC"/>
			</section>
		</section>
	</section>
</section>