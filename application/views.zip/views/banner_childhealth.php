	<h3 align="center"> CHILD HEALTH COMMODITIES ASSESSMENT</h3>
	
	<p style="text-align: center;color:#872300">
			Indicate the quantities of the Zinc,ORS,Ciprofloxacin &amp; Metronidazole (Flagyl) available in this facility at the:
	</p>